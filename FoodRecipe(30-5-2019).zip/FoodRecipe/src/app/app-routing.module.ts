import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SearchComponent } from './search/search.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { BreadrecipeComponent } from './breadrecipe/breadrecipe.component';
import { BlueberrybreadComponent } from './blueberrybread/blueberrybread.component';

const routes: Routes = [{ path: 'about',pathMatch: 'full', component:  AboutComponent},
{path: 'login',pathMatch: 'full', component:  LoginComponent},
{path: 'signup',pathMatch: 'full', component:  SignupComponent},
{path: 'search',pathMatch: 'full', component:  SearchComponent},
{path: 'admin',pathMatch: 'full', component:  AdminComponent},
{path: 'user',pathMatch: 'full', component:  UserComponent},
{path: 'home',pathMatch: 'full', component:  HomeComponent},
{path: 'breadrecipe',pathMatch: 'full', component:  BreadrecipeComponent},
{path: 'blueberrybread',pathMatch: 'full', component:  BlueberrybreadComponent},
{path: '',redirectTo: 'HomeComponent',pathMatch: 'full'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
