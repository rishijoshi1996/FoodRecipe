import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlueberrybreadComponent } from './blueberrybread.component';

describe('BlueberrybreadComponent', () => {
  let component: BlueberrybreadComponent;
  let fixture: ComponentFixture<BlueberrybreadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlueberrybreadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlueberrybreadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
